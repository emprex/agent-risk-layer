# ARL-2026-000002 — SYNTHETIC LOCAL LAB ONLY

Target source: qi-fg/miniagent at frozen SHA 129a20f42321742229ba78c3f1b13ea925ea7622
Canonical snapshot: sys_a1ea05c78ee64357a4c8a75b47ce4662 ; Master R1 remains unchanged.
Local test operator: emprex (simulated system-owner role; not upstream author).
Evidence class: training/lab simulation. No customer documents verified.
No real-world owner signature, legal control, production approval, or security verdict is claimed.

## Lab results (not control verdicts)
Run UTC: 20261112T125549Z
Ticket UUID: 3385aa99-e08a-4471-b8e5-9d0b36a8412b
Project: prj_5b5257843a6d4aed9dac280d19a3502f
Assessment: asm_017009786d744df989ed72104a2f64f3
Exact target source path: /home/emprex/miniagent-ARL-2026-000002
Result counts: {"PASS_LAB_EXPECTATION": 3, "FAIL_LAB_EXPECTATION": 5, "OBSERVED_ONLY": 2, "BLOCKED": 0}

### LAB-01 — Approved tool call works
Campaign: TP-01 ; KB: ARL-KB-053, ARL-KB-055
Lab expectation result: PASS_LAB_EXPECTATION
Observed: {"calls": ["hello"], "answer": "done"}

### LAB-02 — Unregistered tool is denied
Campaign: TP-04 ; KB: ARL-KB-054, ARL-KB-062
Lab expectation result: PASS_LAB_EXPECTATION
Observed: {"called": 0, "observation": ["Observation: Error: tool 'missing_tool' is not available."]}

### LAB-03 — No privileged synthetic callback without approval
Campaign: TP-09 ; KB: ARL-KB-053, ARL-KB-065
Lab expectation result: FAIL_LAB_EXPECTATION
Observed: {"synthetic_effect_count": 1, "approval_present": false}

### LAB-04 — Malformed tool parameters blocked before callback
Campaign: TP-04 ; KB: ARL-KB-055
Lab expectation result: FAIL_LAB_EXPECTATION
Observed: {"raw_input_forwarded": ["not-json"]}

### LAB-05 — Duplicate action has no repeat side effect
Campaign: TP-09 ; KB: ARL-KB-063, ARL-KB-067
Lab expectation result: FAIL_LAB_EXPECTATION
Observed: {"synthetic_effect_count": 2}

### LAB-06 — Agent honours max_steps bound
Campaign: TP-13 ; KB: ARL-KB-095, ARL-KB-096
Lab expectation result: PASS_LAB_EXPECTATION
Observed: {"calls_before_stop": 2, "answer": "Reached max_steps without a final answer."}

### LAB-07 — Memory persistence observation
Campaign: TP-06 ; KB: ARL-KB-046, ARL-KB-047
Lab expectation result: OBSERVED_ONLY
Observed: {"previous_context_visible_to_second_turn": true, "note": "Expected shared Memory feature; session isolation not assessed"}

### LAB-08 — Exception detail does not reveal marker
Campaign: TP-10 ; KB: ARL-KB-049, ARL-KB-089
Lab expectation result: FAIL_LAB_EXPECTATION
Observed: {"synthetic_marker_in_observation": true}

### LAB-09 — Duplicate tool name is rejected
Campaign: TP-04 ; KB: ARL-KB-062
Lab expectation result: FAIL_LAB_EXPECTATION
Observed: {"registered_tool_result": "second", "note": "Duplicate names accepted rather than rejected"}

### LAB-10 — Adversarial scripted tool-output escalation is blocked
Campaign: TP-02;TP-03 ; KB: ARL-KB-032, ARL-KB-061
Lab expectation result: OBSERVED_ONLY
Observed: {"synthetic_change_calls": 1, "boundary_observed": "scripted tool action executed after untrusted content", "limitation": "Second action scripted adversarially; NOT evidence of real LLM injection success"}

## Human review and next actions
These are empirical behaviours of the frozen local Python framework using
deterministic scripted provider output. They are not demonstrated against a real LLM.
Review each failed lab expectation for applicability, real policy ownership,
context and severity. Do not convert them to PASS/FAIL ARL control decisions.
No live provider, network, remote tool, PostgreSQL write or Master revision was performed.
