# ARL-2026-000002 — SYNTHETIC LOCAL LAB ONLY

Target source: qi-fg/miniagent at frozen SHA 129a20f42321742229ba78c3f1b13ea925ea7622
Canonical snapshot: sys_a1ea05c78ee64357a4c8a75b47ce4662 ; Master R1 remains unchanged.
Local test operator: emprex (simulated system-owner role; not upstream author).
Evidence class: training/lab simulation. No customer documents verified.
No real-world owner signature, legal control, production approval, or security verdict is claimed.

## Lab owner declaration (SIMULATED)
AGENTRISKLAYER LTD — Internal Lab is the fictional customer and operator of this local clone.
Permitted: read-only source examination, in-process ScriptedProvider, synthetic tools,
dummy strings and in-memory counters. These tests are limited to this local machine
and this frozen revision, and were requested by the operator in this conversation.

Prohibited: production effects; remote targets; network requests; genuine secrets;
real payment, email, shell or privileged filesystem tools; persistence to the canonical ARL DB.

## Synthetic test authorisation
Status: LAB-ONLY EXERCISE AUTHORISED BY OPERATOR IN CHAT.
Not a signed client approval, not independent verification of ownership.
This document does not grant authority to test the public GitHub project's
infrastructure, its maintainer, or any third-party service.

## Stop conditions
Wrong Git SHA, changed canonical Master/snapshot, modified tracked files,
an unapproved tool or network dependency, unexpected external effects or
test-harness error. Stop the process; preserve logs. No automated deployment.

## Master handling
Master R1 is read and checked but NEVER modified. Lab artefacts are intentionally
separate and may be reviewed for canonical candidate-evidence handoff later,
without being represented as independently authenticated owner evidence.
