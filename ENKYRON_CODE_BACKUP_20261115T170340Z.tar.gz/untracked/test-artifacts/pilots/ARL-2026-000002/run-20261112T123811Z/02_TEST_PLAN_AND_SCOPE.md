# ARL-2026-000002 — SYNTHETIC LOCAL LAB ONLY

Target source: qi-fg/miniagent at frozen SHA 129a20f42321742229ba78c3f1b13ea925ea7622
Canonical snapshot: sys_a1ea05c78ee64357a4c8a75b47ce4662 ; Master R1 remains unchanged.
Local test operator: emprex (simulated system-owner role; not upstream author).
Evidence class: training/lab simulation. No customer documents verified.
No real-world owner signature, legal control, production approval, or security verdict is claimed.

## Campaign catalogue (not automatic authorisation)
- TP-01: Approved tool execution and baseline — local scenario links: LAB-01
- TP-02: Direct prompt and goal integrity — local scenario links: LAB-10
- TP-03: Indirect tool-result instruction trust — local scenario links: LAB-10
- TP-04: Tool allowlisting, schema and name collisions — local scenario links: LAB-02, LAB-04, LAB-09
- TP-05: Command, filesystem, egress and containment — local scenario links: NOT TESTED
- TP-06: Memory, session, retrieval and persistence — local scenario links: LAB-07
- TP-07: Authentication, role and delegation — local scenario links: NOT TESTED
- TP-08: MCP and inter-agent identity — local scenario links: NOT TESTED
- TP-09: Approval and replay integrity — local scenario links: LAB-03, LAB-05
- TP-10: Output safety and disclosure — local scenario links: LAB-08
- TP-11: Model, build and dependency provenance — local scenario links: NOT TESTED
- TP-12: Runtime policy and evidence integrity — local scenario links: NOT TESTED
- TP-13: Iteration bounds and resilience — local scenario links: LAB-06
- TP-14: Remediation and exact retest — local scenario links: NOT TESTED

All cases use actual frozen miniagent Python code and a scripted offline provider.
Real LLM resistance, provider behaviour, MCP, multi-user and production boundaries
are NOT established. FAIL means this lab's explicit expected boundary was not met;
it is not an automatically validated ARL finding or control verdict.
