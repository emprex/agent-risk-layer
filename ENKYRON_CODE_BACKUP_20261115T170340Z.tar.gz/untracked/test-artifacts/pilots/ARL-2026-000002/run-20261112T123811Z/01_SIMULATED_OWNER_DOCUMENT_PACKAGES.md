# ARL-2026-000002 — SYNTHETIC LOCAL LAB ONLY

Target source: qi-fg/miniagent at frozen SHA 129a20f42321742229ba78c3f1b13ea925ea7622
Canonical snapshot: sys_a1ea05c78ee64357a4c8a75b47ce4662 ; Master R1 remains unchanged.
Local test operator: emprex (simulated system-owner role; not upstream author).
Evidence class: training/lab simulation. No customer documents verified.
No real-world owner signature, legal control, production approval, or security verdict is claimed.

## 12 consolidated owner-document packages (SIMULATED)

### DOC-01 — Governance and scope
Controls: ARL-KB-001, ARL-KB-002, ARL-KB-003, ARL-KB-004, ARL-KB-005, ARL-KB-006, ARL-KB-007, ARL-KB-008, ARL-KB-009, ARL-KB-010
Simulated owner statement: Assumed lab-only purpose: assess a frozen Python agent framework with synthetic tools. Local operator is the simulated accountable owner; no upstream repository ownership is claimed. Approved effects: in-memory counters and dummy strings. No production or customer data.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-02 — Inventory and architecture
Controls: ARL-KB-011, ARL-KB-012, ARL-KB-013, ARL-KB-014, ARL-KB-015, ARL-KB-016, ARL-KB-017, ARL-KB-018
Simulated owner statement: Frozen qi-fg/miniagent source: Python Agent ReAct loop, ToolRegistry, Memory, Mock/OpenAI/Anthropic/Ollama provider classes. This run imports source from the exact frozen local Git revision and uses only an in-process scripted provider.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-03 — Identity, access and tenant isolation
Controls: ARL-KB-019, ARL-KB-020, ARL-KB-021, ARL-KB-022, ARL-KB-023, ARL-KB-024, ARL-KB-025, ARL-KB-026, ARL-KB-027, ARL-KB-028, ARL-KB-029, ARL-KB-030
Simulated owner statement: Simulation contains one local operator and synthetic identities only. It claims no real IAM, SSO, tenant isolation or privilege delegation implementation; these require evidence before any production conclusion.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-04 — Prompt, input and goal integrity
Controls: ARL-KB-031, ARL-KB-032, ARL-KB-033, ARL-KB-034, ARL-KB-035, ARL-KB-036, ARL-KB-037, ARL-KB-038, ARL-KB-039, ARL-KB-040
Simulated owner statement: The lab uses adversarial synthetic provider responses and tool observations. These demonstrate execution boundaries, not measured attack success against an actual LLM. No real user prompts or external documents are submitted.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-05 — Data, privacy, retrieval and memory
Controls: ARL-KB-041, ARL-KB-042, ARL-KB-043, ARL-KB-044, ARL-KB-045, ARL-KB-046, ARL-KB-047, ARL-KB-048, ARL-KB-049, ARL-KB-050, ARL-KB-051, ARL-KB-052
Simulated owner statement: Only dummy values are allowed. Memory is exercised in-process; no real personal data, retrieval index or third-party content is used. Actual production retention, RAG and privacy controls remain unverified.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-06 — Tools, MCP and agent authority
Controls: ARL-KB-053, ARL-KB-054, ARL-KB-055, ARL-KB-056, ARL-KB-057, ARL-KB-058, ARL-KB-059, ARL-KB-060, ARL-KB-061, ARL-KB-062, ARL-KB-063, ARL-KB-064
Simulated owner statement: Synthetic callback tools are registered explicitly. No shell, filesystem-changing, email, payment or network tools are registered. MCP capability is not assumed to exist in this frozen miniagent target.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-07 — Human approval and transaction integrity
Controls: ARL-KB-065, ARL-KB-066, ARL-KB-067, ARL-KB-068, ARL-KB-069, ARL-KB-070, ARL-KB-071, ARL-KB-072
Simulated owner statement: The operator's chat instruction authorises this isolated exercise. This is a simulated lab rules-of-engagement record, not a signed customer permission. No high-impact real action is approved.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-08 — Model and software supply chain
Controls: ARL-KB-073, ARL-KB-074, ARL-KB-075, ARL-KB-076, ARL-KB-077, ARL-KB-078, ARL-KB-079, ARL-KB-080
Simulated owner statement: The target Git HEAD must match the frozen commit. The local Python package is loaded without an external model. This does not authenticate upstream provenance, verify packages or prove SBOM completeness.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-09 — Output and downstream safety
Controls: ARL-KB-081, ARL-KB-082, ARL-KB-083, ARL-KB-084, ARL-KB-085, ARL-KB-086
Simulated owner statement: Synthetic outputs and exception messages are inspected; no HTML renderer, production database, external email or web sink is invoked. Downstream application validation remains unverified.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-10 — Runtime policy, monitoring and evidence
Controls: ARL-KB-087, ARL-KB-088, ARL-KB-089, ARL-KB-090, ARL-KB-091, ARL-KB-092, ARL-KB-093, ARL-KB-094
Simulated owner statement: The script captures expected versus observed in-process behaviour and hashes the generated artefacts. SHA-256 provides consistency, not a digital signature or independent authenticity verification.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-11 — Availability, cost and resilience
Controls: ARL-KB-095, ARL-KB-096, ARL-KB-097, ARL-KB-098, ARL-KB-099, ARL-KB-100
Simulated owner statement: The ReAct iteration bound is tested with scripted responses. The lab uses no billable model or API call. Runtime cost, provider outages and real external throttling are outside this offline exercise.
Authority: lab scenario only; no production documentary evidence submitted.

### DOC-12 — Incident response, recovery and deployment
Controls: ARL-KB-101, ARL-KB-102, ARL-KB-103, ARL-KB-104, ARL-KB-105, ARL-KB-106, ARL-KB-107, ARL-KB-108
Simulated owner statement: Lab effects are in-memory only; terminate the local process to stop execution. No deployment or release is permitted from these results. Findings require human review and exact retest before closure.
Authority: lab scenario only; no production documentary evidence submitted.
