# ARL — Static Bug Candidates

Generated: 2026-10-14T12:36:33.001Z
Findings: 56

> ESLint findings are candidates, not confirmed bugs.
> Severity, applicability and remediation require human review.

## Candidate 001

- File: `src/agent/arl-conversation-orchestrator.mjs`
- Line: 135
- Column: 47
- Rule: `no-unused-vars`
- Message: 'handoff' is defined but never used.
- Status: Unreviewed

## Candidate 002

- File: `src/agent/changed-system-snapshot-handoff.mjs`
- Line: 4
- Column: 8
- Rule: `no-unused-vars`
- Message: 'path' is defined but never used.
- Status: Unreviewed

## Candidate 003

- File: `src/agent/deterministic-evidence-collector.mjs`
- Line: 120
- Column: 49
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \".
- Status: Unreviewed

## Candidate 004

- File: `src/agent/deterministic-evidence-collector.mjs`
- Line: 120
- Column: 76
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \".
- Status: Unreviewed

## Candidate 005

- File: `src/agent/deterministic-evidence-collector.mjs`
- Line: 125
- Column: 42
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \".
- Status: Unreviewed

## Candidate 006

- File: `src/agent/deterministic-evidence-collector.mjs`
- Line: 125
- Column: 87
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \".
- Status: Unreviewed

## Candidate 007

- File: `src/agent/deterministic-evidence-collector.mjs`
- Line: 125
- Column: 95
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \".
- Status: Unreviewed

## Candidate 008

- File: `src/agent/kb027-active-executor.mjs`
- Line: 37
- Column: 14
- Rule: `no-undef`
- Message: 'AbortSignal' is not defined.
- Status: Unreviewed

## Candidate 009

- File: `src/agent/local-assessment-workflow.mjs`
- Line: 2336
- Column: 19
- Rule: `no-undef`
- Message: 'AbortSignal' is not defined.
- Status: Unreviewed

## Candidate 010

- File: `src/agent/local-target-adapter-gate.mjs`
- Line: 76
- Column: 15
- Rule: `no-undef`
- Message: 'AbortSignal' is not defined.
- Status: Unreviewed

## Candidate 011

- File: `src/agent/pilot-evidence-lineage-triage.mjs`
- Line: 220
- Column: 36
- Rule: `no-unused-vars`
- Message: 'observations' is defined but never used.
- Status: Unreviewed

## Candidate 012

- File: `src/agent/remediation-applicability-handoff.mjs`
- Line: 58
- Column: 10
- Rule: `no-unused-vars`
- Message: 'parseJson' is defined but never used.
- Status: Unreviewed

## Candidate 013

- File: `src/agent/tools/get-authoritative-assessment.mjs`
- Line: 64
- Column: 7
- Rule: `no-useless-assignment`
- Message: The value assigned to 'result' is not used in subsequent statements.
- Status: Unreviewed

## Candidate 014

- File: `src/agent/tools/get-authoritative-assessment.mjs`
- Line: 77
- Column: 7
- Rule: `no-useless-assignment`
- Message: The value assigned to 'answers' is not used in subsequent statements.
- Status: Unreviewed

## Candidate 015

- File: `src/agent/tools/resolve-persisted-exact-retest-continuation.mjs`
- Line: 158
- Column: 7
- Rule: `no-useless-assignment`
- Message: The value assigned to 'equivalentBaselineRunIds' is not used in subsequent statements.
- Status: Unreviewed

## Candidate 016

- File: `src/agent/tools/run-authoritative-control-test.mjs`
- Line: 199
- Column: 24
- Rule: `no-unused-vars`
- Message: 'checkDigest' is assigned a value but never used.
- Status: Unreviewed

## Candidate 017

- File: `src/auth.js`
- Line: 104
- Column: 13
- Rule: `preserve-caught-error`
- Message: There is no `cause` attached to the symptom error being thrown.
- Status: Unreviewed

## Candidate 018

- File: `src/auth.js`
- Line: 346
- Column: 11
- Rule: `no-empty`
- Message: Empty block statement.
- Status: Unreviewed

## Candidate 019

- File: `src/config.js`
- Line: 22
- Column: 35
- Rule: `no-control-regex`
- Message: Unexpected control character(s) in regular expression: \x00.
- Status: Unreviewed

## Candidate 020

- File: `src/content-security.js`
- Line: 28
- Column: 21
- Rule: `no-undef`
- Message: 'performance' is not defined.
- Status: Unreviewed

## Candidate 021

- File: `src/content-security.js`
- Line: 62
- Column: 35
- Rule: `no-undef`
- Message: 'performance' is not defined.
- Status: Unreviewed

## Candidate 022

- File: `src/content-security.js`
- Line: 85
- Column: 19
- Rule: `no-empty`
- Message: Empty block statement.
- Status: Unreviewed

## Candidate 023

- File: `src/content-security.js`
- Line: 95
- Column: 40
- Rule: `no-control-regex`
- Message: Unexpected control character(s) in regular expression: \x09, \x0a, \x0d.
- Status: Unreviewed

## Candidate 024

- File: `src/control-intelligence-core.js`
- Line: 436
- Column: 60
- Rule: `no-unused-vars`
- Message: 'userId' is defined but never used.
- Status: Unreviewed

## Candidate 025

- File: `src/control-intelligence-core.js`
- Line: 1001
- Column: 11
- Rule: `no-unused-vars`
- Message: 'evidence' is assigned a value but never used.
- Status: Unreviewed

## Candidate 026

- File: `src/control-intelligence-core.js`
- Line: 1018
- Column: 11
- Rule: `no-unused-vars`
- Message: 'executed' is assigned a value but never used.
- Status: Unreviewed

## Candidate 027

- File: `src/control-intelligence-core.js`
- Line: 1030
- Column: 199
- Rule: `no-useless-assignment`
- Message: The value assigned to 'nextAction' is not used in subsequent statements.
- Status: Unreviewed

## Candidate 028

- File: `src/control-intelligence-core.js`
- Line: 1030
- Column: 267
- Rule: `no-useless-assignment`
- Message: The value assigned to 'deploymentImpact' is not used in subsequent statements.
- Status: Unreviewed

## Candidate 029

- File: `src/control-intelligence-core.js`
- Line: 1280
- Column: 104
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \-.
- Status: Unreviewed

## Candidate 030

- File: `src/control-intelligence-core.js`
- Line: 1280
- Column: 138
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \/.
- Status: Unreviewed

## Candidate 031

- File: `src/control-intelligence-historical.js`
- Line: 7
- Column: 43
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \-.
- Status: Unreviewed

## Candidate 032

- File: `src/control-intelligence-historical.js`
- Line: 7
- Column: 77
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \/.
- Status: Unreviewed

## Candidate 033

- File: `src/control-plane-core.js`
- Line: 309
- Column: 19
- Rule: `no-undef`
- Message: 'performance' is not defined.
- Status: Unreviewed

## Candidate 034

- File: `src/control-plane-core.js`
- Line: 358
- Column: 36
- Rule: `no-undef`
- Message: 'performance' is not defined.
- Status: Unreviewed

## Candidate 035

- File: `src/control-plane-core.js`
- Line: 823
- Column: 86
- Rule: `no-extra-boolean-cast`
- Message: Redundant Boolean call.
- Status: Unreviewed

## Candidate 036

- File: `src/control-plane-core.js`
- Line: 1330
- Column: 20
- Rule: `no-unused-vars`
- Message: '_version' is assigned a value but never used.
- Status: Unreviewed

## Candidate 037

- File: `src/db-adapters/postgres.js`
- Line: 129
- Column: 55
- Rule: `no-empty`
- Message: Empty block statement.
- Status: Unreviewed

## Candidate 038

- File: `src/db-adapters/sqlite-local.js`
- Line: 733
- Column: 49
- Rule: `no-empty`
- Message: Empty block statement.
- Status: Unreviewed

## Candidate 039

- File: `src/email.js`
- Line: 76
- Column: 21
- Rule: `no-undef`
- Message: 'AbortSignal' is not defined.
- Status: Unreviewed

## Candidate 040

- File: `src/fix-prove-evidence.js`
- Line: 18
- Column: 38
- Rule: `no-control-regex`
- Message: Unexpected control character(s) in regular expression: \x00, \x1f.
- Status: Unreviewed

## Candidate 041

- File: `src/github-source-inspection.js`
- Line: 52
- Column: 13
- Rule: `no-undef`
- Message: 'AbortSignal' is not defined.
- Status: Unreviewed

## Candidate 042

- File: `src/github-source-inspection.js`
- Line: 84
- Column: 13
- Rule: `no-undef`
- Message: 'AbortSignal' is not defined.
- Status: Unreviewed

## Candidate 043

- File: `src/inspector.js`
- Line: 377
- Column: 65
- Rule: `no-control-regex`
- Message: Unexpected control character(s) in regular expression: \x00, \x1f.
- Status: Unreviewed

## Candidate 044

- File: `src/pdf.js`
- Line: 54
- Column: 11
- Rule: `no-unused-vars`
- Message: 'label' is assigned a value but never used.
- Status: Unreviewed

## Candidate 045

- File: `src/redteam.js`
- Line: 113
- Column: 9
- Rule: `no-useless-assignment`
- Message: The value assigned to 'recoveryValidation' is not used in subsequent statements.
- Status: Unreviewed

## Candidate 046

- File: `src/redteam.js`
- Line: 658
- Column: 65
- Rule: `no-control-regex`
- Message: Unexpected control character(s) in regular expression: \x00, \x1f.
- Status: Unreviewed

## Candidate 047

- File: `src/report.js`
- Line: 39
- Column: 11
- Rule: `no-unused-vars`
- Message: 'attackPaths' is assigned a value but never used.
- Status: Unreviewed

## Candidate 048

- File: `src/retention.js`
- Line: 2
- Column: 31
- Rule: `no-unused-vars`
- Message: 'nowIso' is defined but never used.
- Status: Unreviewed

## Candidate 049

- File: `src/risk-knowledge-core.js`
- Line: 229
- Column: 24
- Rule: `no-useless-escape`
- Message: Unnecessary escape character: \/.
- Status: Unreviewed

## Candidate 050

- File: `src/risk-knowledge.js`
- Line: 14
- Column: 3
- Rule: `no-unused-vars`
- Message: 'validateArchitectureFacts' is defined but never used.
- Status: Unreviewed

## Candidate 051

- File: `src/runtime-policy.js`
- Line: 43
- Column: 21
- Rule: `no-undef`
- Message: 'performance' is not defined.
- Status: Unreviewed

## Candidate 052

- File: `src/runtime-policy.js`
- Line: 119
- Column: 35
- Rule: `no-undef`
- Message: 'performance' is not defined.
- Status: Unreviewed

## Candidate 053

- File: `src/runtime-policy.js`
- Line: 153
- Column: 19
- Rule: `no-empty`
- Message: Empty block statement.
- Status: Unreviewed

## Candidate 054

- File: `src/security.js`
- Line: 61
- Column: 17
- Rule: `no-useless-assignment`
- Message: The value assigned to 'allowed' is not used in subsequent statements.
- Status: Unreviewed

## Candidate 055

- File: `src/security.js`
- Line: 102
- Column: 47
- Rule: `no-control-regex`
- Message: Unexpected control character(s) in regular expression: \x00, \x1f.
- Status: Unreviewed

## Candidate 056

- File: `src/workspaces.js`
- Line: 124
- Column: 102
- Rule: `no-undef`
- Message: 'AbortSignal' is not defined.
- Status: Unreviewed
