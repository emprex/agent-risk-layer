const fs = require('node:fs');
const path = require('node:path');

const dir = __dirname;
const reportFile = fs.readdirSync(dir)
  .find(name => name.endsWith('1000-scenario-results.json'));

if (!reportFile) {
  throw new Error('Rapport des scénarios introuvable');
}

const { summary } = JSON.parse(
  fs.readFileSync(path.join(dir, reportFile), 'utf8')
);

function readLog(name) {
  return fs.readFileSync(path.join(dir, name), 'utf8');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;',
    '"': '&quot;', "'": '&#39;'
  })[char]);
}

const syntaxLog = readLog('syntax.log');
const testLog = readLog('access-control.log');

const html = `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ARL — Diagnostic Report</title>
<style>
body { font-family: system-ui, sans-serif; background:#101827;
       color:#e5e7eb; max-width:1000px; margin:40px auto; padding:20px; }
h1 { color:#93c5fd; }
.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:16px; }
.card { background:#1e293b; border-radius:12px; padding:22px; }
.value { font-size:32px; font-weight:700; }
.good { color:#4ade80; }
pre { background:#020617; padding:16px; overflow:auto; white-space:pre-wrap; }
small { color:#94a3b8; }
</style>
</head>
<body>
<h1>AgentRiskLayer — Diagnostic Report</h1>
<p>Version ${escapeHtml(summary.release)}</p>
<p>Rapport des scénarios : ${escapeHtml(summary.generatedAt)}</p>
<div class="grid">
<div class="card"><h3>Scénarios réussis</h3>
<div class="value good">${summary.passed}/${summary.scenarios}</div></div>
<div class="card"><h3>Scénarios échoués</h3>
<div class="value">${summary.failed}</div></div>
<div class="card"><h3>Chemins critiques</h3>
<div class="value">${summary.criticalPathScenarios}</div></div>
<div class="card"><h3>Décisions dangereuses détectées</h3>
<div class="value">${summary.unsafeDecisions}</div></div>
</div>
<h2>Analyse syntaxique — journal</h2>
<pre>${escapeHtml(syntaxLog)}</pre>
<h2>Contrôle d'accès — journal des tests</h2>
<pre>${escapeHtml(testLog)}</pre>
<h2>Limites</h2>
<p>Rapport fondé sur les résultats existants. Les journaux ne suffisent pas
à certifier la sécurité du logiciel. Les tests complets, l'analyse statique
de sécurité et l'audit des dépendances restent à réaliser.</p>
<small>Aucune décision de déploiement ne doit être automatisée à partir de ce rapport.</small>
</body>
</html>`;

const output = path.join(dir, 'arl-diagnostic-report.html');
fs.writeFileSync(output, html);
console.log('Rapport créé :', output);
