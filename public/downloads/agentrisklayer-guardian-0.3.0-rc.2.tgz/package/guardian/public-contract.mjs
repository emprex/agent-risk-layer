/**
 * ARL Guardian — public handoff contract
 * Author / Founder: Guillaume Strohecker
 * Project: AgentRiskLayer (AGENTRISKLAYER LTD)
 *
 * This file is intentionally small and safe to ship with the standalone
 * Guardian package. It contains only the candidate architecture-fact labels
 * that Guardian is allowed to prepare for later human confirmation.
 *
 * It does NOT contain ARL control logic, applicability rules, findings,
 * severity logic, readiness logic, assessment state, or private control data.
 */

import crypto from 'node:crypto';

export const GUARDIAN_PUBLIC_CONTRACT_VERSION = '1.0.0';

export const GUARDIAN_CANDIDATE_ARCHITECTURE_FACTS = Object.freeze([
  'data:secrets',
  'tool:code_execution',
  'tool:file',
  'tool:network',
  'tool:write',
]);

export const GUARDIAN_PUBLIC_CONTRACT_DIGEST = crypto
  .createHash('sha256')
  .update(GUARDIAN_CANDIDATE_ARCHITECTURE_FACTS.join('\n'))
  .digest('hex');
