/**
 * ARL Guardian — human review handoff
 * Author / Founder: Guillaume Strohecker
 * Project: AgentRiskLayer (AGENTRISKLAYER LTD)
 *
 * This module is the authority boundary between static Guardian observations
 * and the existing ARL assessment workflow. It may prepare candidate facts and
 * review questions, but it never confirms architecture facts or applicability.
 */

import {
  GUARDIAN_CANDIDATE_ARCHITECTURE_FACTS,
  GUARDIAN_PUBLIC_CONTRACT_DIGEST,
  GUARDIAN_PUBLIC_CONTRACT_VERSION,
} from './public-contract.mjs';

export const GUARDIAN_HANDOFF_SCHEMA = 'arl.guardian.review-handoff.v1';

// Profiles define what a human assessor should verify for each observed family.
// Candidate facts are deliberately sparse and always remain unconfirmed.
const REVIEW_PROFILES = Object.freeze({
  approval_or_boundary_control: Object.freeze({
    candidateFacts: [],
    questions: [
      'What exact action, target, or parameter set does the detected boundary control?',
      'Is the boundary enforced outside the model or prompt layer?',
      'Can the action target or parameters change after approval or policy evaluation?',
      'Are bypass, replay, and exceptional paths constrained and auditable?',
    ],
    note: 'The detector combines approval, allow/deny, sandbox, and bounded-target indicators, so no single safeguard fact is safe to infer automatically.',
  }),
  credential_reference: Object.freeze({
    candidateFacts: ['data:secrets'],
    questions: [
      'Which credential or secret class is referenced, and which component can access it?',
      'Is the credential scoped to the minimum required actions and targets?',
      'Can the agent, tools, or untrusted content expose or redirect use of the credential?',
      'How is credential use logged, rotated, and revoked?',
    ],
  }),
  filesystem_write: Object.freeze({
    candidateFacts: ['tool:file', 'tool:write'],
    questions: [
      'Can the agent itself cause filesystem writes, or is the write limited to supporting application code?',
      'Which paths and file operations are allowed?',
      'Are targets constrained to an explicit working area or sandbox?',
      'Are destructive or overwrite operations separately controlled and recoverable?',
    ],
  }),
  mcp: Object.freeze({
    candidateFacts: [],
    questions: [
      'Which MCP servers and tools can the agent invoke?',
      'Which MCP tools are read-only and which can create external side effects?',
      'How are MCP server identity, trust, and configuration established?',
      'Can untrusted content or tool output influence subsequent MCP tool selection or parameters?',
    ],
    note: 'MCP presence alone does not establish a canonical ARL tool authority fact; explicit MCP-to-agent/tool bridge evidence makes the integration agent-relevant for review, but the concrete tools and permissions must still be confirmed by a human.',
  }),
  outbound_network: Object.freeze({
    candidateFacts: ['tool:network'],
    questions: [
      'Which destinations can the agent or agent runtime reach?',
      'Are outbound destinations constrained by allowlist, policy, or another external enforcement point?',
      'Which identities or credentials are available to outbound requests?',
      'Can untrusted content influence the destination, method, headers, or request parameters?',
    ],
  }),
  process_execution: Object.freeze({
    candidateFacts: ['tool:code_execution'],
    questions: [
      'Can the agent itself trigger process or command execution?',
      'Which binaries, commands, arguments, and working directories are permitted?',
      'Is execution isolated or sandboxed from the host and sensitive resources?',
      'Are command construction, approvals, logging, and recovery controls enforced outside the model?',
    ],
  }),
});

/** Build the decision-support package presented to the human ARL assessor. */
export function buildGuardianReviewHandoff(capabilitySurface = []) {
  return {
    schema: GUARDIAN_HANDOFF_SCHEMA,
    authority: 'decision_support_only',
    architecture_facts_confirmed: false,
    control_applicability_determined: false,
    public_contract: {
      version: GUARDIAN_PUBLIC_CONTRACT_VERSION,
      digest: GUARDIAN_PUBLIC_CONTRACT_DIGEST,
    },
    items: capabilitySurface.map(buildHandoffItem),
    limitations: 'Guardian proposes review questions and candidate architecture facts only. Candidate facts require human confirmation before the private ARL assessment engine may use them. Guardian does not determine control applicability, findings, severity, or readiness.',
  };
}

/**
 * Convert one capability family into a conservative human-review item.
 * A candidate fact exists only when agent-relevant evidence exists and the fact
 * is part of Guardian's deliberately small public handoff contract.
 */
export function buildHandoffItem(surface) {
  const profile = REVIEW_PROFILES[surface.capability] || Object.freeze({ candidateFacts: [], questions: [] });
  const agentRelevantEvidenceCount = Number(surface.agent_relevant_evidence_count || 0);
  const canPrepareFacts = agentRelevantEvidenceCount > 0;
  const facts = canPrepareFacts ? validateCandidateFacts(profile.candidateFacts || []) : [];

  return {
    capability: surface.capability,
    display_name: surface.display_name,
    evidence_count: surface.evidence_count,
    agent_relevant_evidence_count: agentRelevantEvidenceCount,
    candidate_architecture_facts: facts.map((fact) => ({
      fact,
      status: 'candidate_not_confirmed',
      basis: `Guardian observed ${surface.display_name.toLowerCase()} in evidence linked to the agent runtime/configuration or an explicit agent/tool bridge.`,
    })),
    review_questions: [...(profile.questions || [])],
    next_step: facts.length
      ? 'Human confirms or rejects candidate architecture facts before ARL control suggestions are generated.'
      : 'Human reviews the evidence and classifies the capability before ARL control suggestions are generated.',
    review_required: true,
    limitations: profile.note || (canPrepareFacts
      ? 'Agent-relevant static evidence supports a candidate fact only; runtime reachability and control applicability remain unproven.'
      : 'No agent-linked runtime, configuration, or explicit tool-bridge evidence was observed for this capability, so Guardian does not prepare an agent architecture fact.'),
  };
}

// This is a package-local allowlist, not the private ARL control engine.
function validateCandidateFacts(facts) {
  const allowed = new Set(GUARDIAN_CANDIDATE_ARCHITECTURE_FACTS);
  const invalid = facts.filter((fact) => !allowed.has(fact));
  if (invalid.length) throw new Error(`Guardian review profile contains unsupported public contract facts: ${invalid.join(', ')}`);
  return [...new Set(facts)].sort();
}