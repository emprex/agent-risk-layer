# ARL Guardian

Local, read-only capability discovery for AI-agent repositories.

**Author / Founder:** Guillaume Strohecker  
**Project:** AgentRiskLayer (AGENTRISKLAYER LTD)

Guardian discovers capability indicators such as MCP integration, outbound network access,
filesystem mutation, process execution, credential references, and approval/boundary controls.
It organises evidence for human review without assigning findings, severity, control
applicability, or deployment readiness.

## Requirements

- Node.js 22.5 or later
- A local repository or source directory to inspect

Guardian requires no database, no LLM, no Ollama, no API key, and no hosted ARL service.

## Commands

```bash
arl-guardian inspect .
arl-guardian inspect . --json
arl-guardian report .
arl-guardian evidence .
```

- `inspect` gives the detailed local console view.
- `report` gives a concise customer-facing Markdown report.
- `evidence` gives the separate technical evidence appendix.

## Authority boundary

Guardian is observational decision support only. Candidate architecture facts are not
confirmed facts. Guardian does not determine findings, severity, control applicability,
or deployment readiness. Human ARL review is required for authoritative assessment decisions.

## Privacy and execution model

- read-only source traversal
- no target code execution
- no symlink following
- no outbound network calls by Guardian
- bounded files, bytes, and observations
- secret-like environment variable names may be reported, but secret values are not emitted

## Package boundary

This standalone package intentionally contains only Guardian discovery, reporting, and the
small public ARL handoff contract. The private ARL control engine, assessment state, findings,
severity logic, runtime testing, persistence, and readiness logic are not included.

This is a pre-release package. Public distribution and licensing terms are not yet defined.
