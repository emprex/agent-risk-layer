#!/usr/bin/env node
/**
 * ARL Guardian — command-line orchestration
 * Author / Founder: Guillaume Strohecker
 * Project: AgentRiskLayer (AGENTRISKLAYER LTD)
 *
 * The CLI wires deterministic inspection, capability grouping, human review
 * handoff, and report generation together. It does not introduce a second
 * security authority: Guardian remains observational and human-reviewed.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { inspectGuardianCapabilities } from '../inspector/guardian-capabilities.mjs';
import {
  classifyEvidenceContext,
  componentFromPath,
  enrichGuardianResult,
  GUARDIAN_SURFACE_VERSION,
} from './capability-surface.mjs';
import { addMcpAuthorityChainEvidence } from './mcp-authority-chain.mjs';
import { buildGuardianReviewHandoff } from './review-handoff.mjs';
import { formatGuardianEvidenceMarkdown, formatGuardianMarkdown } from './markdown-report.mjs';

const CONTEXT_LABELS = Object.freeze({
  agent_runtime: 'agent runtime',
  agent_configuration: 'agent/configuration',
  integration_surface: 'integration surface',
  application_backend: 'application backend',
  dashboard_ui: 'dashboard/UI',
  application_source: 'application source',
  repository_configuration: 'repository configuration',
  example_or_sample: 'example/sample',
  test_or_fixture: 'test/fixture',
  developer_tooling: 'developer tooling',
  documentation: 'documentation',
});

const USAGE = 'Usage: arl-guardian inspect <repository> [--json] | arl-guardian report <repository> | arl-guardian evidence <repository>';

/**
 * Build one complete Guardian result while preserving the authority chain:
 * raw observation -> correlated authority evidence -> capability surface -> review handoff.
 */
export function buildGuardianResult(target) {
  const inspected = addMcpAuthorityChainEvidence(inspectGuardianCapabilities(target));
  const result = enrichGuardianResult(inspected);
  return {
    ...result,
    review_handoff: buildGuardianReviewHandoff(result.capability_surface),
  };
}

/** Format the assessor/operator console view, including raw observations. */
export function formatGuardianReport(result) {
  const lines = [
    `ARL Guardian v${GUARDIAN_SURFACE_VERSION}`,
    '==================',
    '',
    'Target',
    '------',
    `Repository: ${result.target.path}`,
    `Revision: ${result.target.git_revision ?? 'not a Git repository'}`,
    `Working tree: ${result.target.git_dirty === null ? 'unknown' : result.target.git_dirty ? 'dirty' : 'clean'}`,
    '',
    'Capability Surface',
    '------------------',
    `Capability families observed: ${result.summary.capability_count}`,
    `Raw evidence observations: ${result.summary.observation_count}`,
  ];

  if (result.capability_surface.length === 0) {
    lines.push('Capabilities detected: none');
  } else {
    for (const surface of result.capability_surface) {
      const evidenceWord = surface.evidence_count === 1 ? 'reference' : 'references';
      const fileWord = surface.file_count === 1 ? 'file' : 'files';
      lines.push(
        '',
        surface.display_name,
        `Observed: ${surface.observed ? 'YES' : 'NO'}`,
        `Evidence: ${surface.evidence_count} ${evidenceWord} across ${surface.file_count} ${fileWord}`,
        `Agent-linked evidence: ${surface.agent_relevant_evidence_count}`,
        `Authority-chain evidence: ${surface.authority_evidence_count ?? 0}`,
        `Contexts: ${formatContexts(surface.contexts)}`,
        `Primary components: ${surface.primary_components.map((item) => `${item.component} (${item.evidence_count})`).join(', ') || 'none'}`,
        `Human review required: ${surface.review_required ? 'YES' : 'NO'}`,
      );
    }
  }

  lines.push(
    '',
    'ARL Review Handoff',
    '------------------',
    'Candidate architecture facts below are NOT confirmed facts and do not establish control applicability.',
  );

  if (!result.review_handoff?.items?.length) {
    lines.push('No capability review handoff items generated.');
  } else {
    for (const item of result.review_handoff.items) {
      const facts = item.candidate_architecture_facts.map((entry) => entry.fact);
      lines.push(
        '',
        item.display_name,
        `Agent-linked evidence: ${item.agent_relevant_evidence_count} of ${item.evidence_count}`,
        `Authority-chain evidence: ${item.authority_evidence_count ?? 0}`,
        `Candidate ARL architecture facts: ${facts.length ? facts.join(', ') : 'none automatically prepared'}`,
        'Review questions:',
        ...item.review_questions.map((question) => `- ${question}`),
        `Next: ${item.next_step}`,
        `Human review required: ${item.review_required ? 'YES' : 'NO'}`,
      );
    }
  }

  // The inspect command is intentionally verbose for assessor/debug use. The
  // customer-facing report command omits this raw observation section.
  lines.push('', 'Raw Observations', '----------------');
  if (result.observations.length === 0) {
    lines.push('No Guardian capability indicators detected in the scanned text scope.');
  } else {
    result.observations.forEach((item, index) => {
      const context = classifyEvidenceContext(item.evidence.path);
      lines.push(
        '',
        `[G-${String(index + 1).padStart(3, '0')}] ${item.detector_id}`,
        item.observation,
        `Capability: ${item.capability}`,
        `Context: ${CONTEXT_LABELS[context] || context}`,
        `Component: ${componentFromPath(item.evidence.path, context)}`,
        `Evidence: ${item.evidence.path}:${item.evidence.line_start}`,
        `Human review required: ${item.review_required ? 'YES' : 'NO'}`,
      );
    });
  }

  lines.push(
    '',
    'Scope',
    '-----',
    `Files considered: ${result.scope.files_considered}`,
    `Truncated: ${result.scope.truncated ? 'YES' : 'NO'}`,
    '',
    'Context labels are heuristic path classifications for evidence organisation only.',
    result.review_handoff?.limitations || 'Guardian review handoff requires human confirmation.',
    result.authority_notice,
  );
  return `${lines.join('\n')}\n`;
}

function formatContexts(contexts) {
  return Object.entries(contexts)
    .map(([context, count]) => `${CONTEXT_LABELS[context] || context}: ${count}`)
    .join(', ') || 'none';
}

/** Parse only the supported, explicit command surface. */
export function parseGuardianArgs(argv) {
  const args = [...argv];
  const command = args.shift();

  if (command === 'report' || command === 'evidence') {
    if (args.some((arg) => arg.startsWith('--')) || args.length > 1) throw new Error(USAGE);
    return { command, target: args[0] || '.' };
  }

  if (command !== 'inspect') throw new Error(USAGE);
  const json = args.includes('--json');
  const positional = args.filter((arg) => arg !== '--json');
  if (positional.length > 1) throw new Error(USAGE);
  return { command: 'inspect', target: positional[0] || '.', json };
}

/** Execute a single local Guardian command and return a process exit code. */
export function runGuardianCli(argv = process.argv.slice(2), io = console) {
  try {
    const parsed = parseGuardianArgs(argv);
    const result = buildGuardianResult(path.resolve(parsed.target));
    if (parsed.command === 'report') io.log(formatGuardianMarkdown(result).trimEnd());
    else if (parsed.command === 'evidence') io.log(formatGuardianEvidenceMarkdown(result).trimEnd());
    else if (parsed.json) io.log(JSON.stringify(result, null, 2));
    else io.log(formatGuardianReport(result).trimEnd());
    return 0;
  } catch (error) {
    io.error(error instanceof Error ? error.message : String(error));
    return 2;
  }
}

/**
 * npm exposes bin entries through a symlink on Unix. Comparing import.meta.url
 * directly with process.argv[1] therefore fails after installation. Resolve both
 * paths to their real file before deciding whether to execute the CLI.
 */
function invokedAsCli() {
  if (!process.argv[1]) return false;
  try {
    const invokedPath = fs.realpathSync(process.argv[1]);
    const modulePath = fs.realpathSync(fileURLToPath(import.meta.url));
    return invokedPath === modulePath;
  } catch {
    return false;
  }
}

if (invokedAsCli()) {
  process.exitCode = runGuardianCli();
}
