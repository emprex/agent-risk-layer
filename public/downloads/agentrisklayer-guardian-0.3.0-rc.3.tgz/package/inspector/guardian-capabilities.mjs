/**
 * ARL Guardian — deterministic capability inspector
 * Author / Founder: Guillaume Strohecker
 * Project: AgentRiskLayer (AGENTRISKLAYER LTD)
 *
 * Guardian is an observational, read-only inspection layer. It identifies
 * capability indicators and evidence locations; it does not create ARL
 * findings, assign severity, determine control applicability, or decide
 * deployment readiness. Those decisions remain subject to human ARL review.
 */

import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

export const GUARDIAN_VERSION = '0.1.0';
export const GUARDIAN_SCHEMA = 'arl.guardian.observations.v1';

// Hard limits keep scans bounded and predictable on customer repositories.
const DEFAULT_LIMITS = Object.freeze({
  maxFiles: 15_000,
  maxReadableFileBytes: 1_000_000,
  maxTotalReadBytes: 24_000_000,
  maxObservations: 1_000,
});

// Generated, dependency, cache, and local-state directories are excluded to
// reduce noise and to avoid inspecting data that is not part of source intent.
const IGNORED_DIRS = new Set([
  '.git', '.hg', '.svn', 'node_modules', 'vendor', 'dist', 'build', 'coverage',
  '.next', '.nuxt', '.cache', '.pytest_cache', '__pycache__', '.venv', 'venv',
  'target', 'out', '.idea', '.vscode', '.terraform', '.serverless', '.agentrisk',
]);

const TEXT_EXTENSIONS = new Set([
  '.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.py', '.rb', '.go', '.rs', '.java',
  '.kt', '.kts', '.cs', '.php', '.sh', '.bash', '.zsh', '.ps1', '.json', '.jsonc',
  '.yaml', '.yml', '.toml', '.ini', '.conf', '.cfg', '.properties',
  '.env', '.dockerfile', '.tf', '.hcl', '.sql', '.swift', '.dart',
]);

const TEXT_BASENAMES = new Set([
  'dockerfile', 'makefile', 'procfile', '.env', '.env.local', '.env.development',
  '.env.test', '.env.production', 'package.json', 'pyproject.toml', 'requirements.txt',
  'mcp.json', '.mcp.json', 'claude_desktop_config.json',
]);

// Credential detection is name-based only. Guardian intentionally never emits
// the corresponding environment value into evidence or reports.
const SENSITIVE_ENV_NAME = /(?:^|_)(?:api_?key|access_?key|secret|token|password|passwd|credential|credentials|auth|private_?key)(?:$|_)/i;

// Detectors identify static capability indicators. A detector hit proves only
// that matching source evidence exists, not that an agent can reach or use it.
const DETECTORS = Object.freeze([
  {
    id: 'GUARDIAN-EXEC-001',
    capability: 'process_execution',
    observation: 'Process or shell execution capability indicator detected',
    patterns: [
      /\b(?:child_process|node:child_process)\b/,
      /(?:^|[^\w.$])(?:exec|execSync|execFile|execFileSync|spawn|spawnSync|fork)\s*\(/,
      /\b(?:child_process|childProcess)\.(?:exec|execSync|execFile|execFileSync|spawn|spawnSync|fork)\s*\(/,
      /\bsubprocess\.(?:run|Popen|call|check_call|check_output)\s*\(/,
      /\basyncio\.create_subprocess_(?:exec|shell)\s*\(/,
      /\bos\.system\s*\(/,
      /\bDeno\.Command\b/,
      /\bBun\.\$\b/,
    ],
  },
  {
    id: 'GUARDIAN-CODE-BRIDGE-001',
    capability: 'process_execution',
    observation: 'Agent-generated code passed to a code executor indicator detected',
    patterns: [
      /\b(?:python_executor|code_executor)\s*\(\s*(?:code_action|generated_code|action_code)\b/i,
      /\b(?:python_executor|code_executor)\.(?:execute|run)\s*\(\s*(?:code_action|generated_code|action_code)\b/i,
    ],
    agentRelevantHint: 'agent_code_execution_bridge',
  },
  {
    id: 'GUARDIAN-NET-001',
    capability: 'outbound_network',
    observation: 'Outbound HTTP or network capability indicator detected',
    patterns: [
      /(?:from\s*['"](?:node:)?https?['"]|require\(\s*['"](?:node:)?https?['"]\s*\))/,
      /\b(?:fetch|axios\.(?:get|post|put|patch|delete|request)|got\.(?:get|post|put|patch|delete))\s*\(/,
      /\b(?:requests|httpx)\.(?:get|post|put|patch|delete|request)\s*\(/,
      /\burllib\.request\b/,
      /\b(?:WebSocket|EventSource)\s*\(/,
    ],
  },
  {
    id: 'GUARDIAN-FS-001',
    capability: 'filesystem_write',
    observation: 'Filesystem mutation capability indicator detected',
    patterns: [
      /\b(?:writeFile|writeFileSync|appendFile|appendFileSync|createWriteStream|unlink|unlinkSync|rm|rmSync|rename|renameSync|mkdir|mkdirSync|copyFile|copyFileSync|truncate|truncateSync)\s*\(/,
      /\bfs\.(?:promises\.)?(?:writeFile|appendFile|unlink|rm|rename|mkdir|copyFile|truncate)\s*\(/,
      /\b(?:write_text|write_bytes|unlink|rename|mkdir|rmdir)\s*\(/,
      /\bshutil\.(?:copy|copy2|copyfile|move|rmtree)\s*\(/,
    ],
  },
  {
    id: 'GUARDIAN-FS-BRIDGE-001',
    capability: 'filesystem_write',
    observation: 'Agent tool delegates filesystem mutation indicator detected',
    patterns: [
      /\bfile_system\.(?:write_file|append_file)\s*\(/i,
    ],
    agentRelevantHint: 'agent_filesystem_tool_bridge',
  },
  {
    id: 'GUARDIAN-MCP-001',
    capability: 'mcp',
    observation: 'MCP server, client, SDK, or tool configuration indicator detected',
    patterns: [
      /@modelcontextprotocol\/sdk/i,
      /["']?mcpServers["']?\s*[:=]/i,
      /\bMcpServer\b/,
      /\bModelContextProtocol\b/i,
      /\bMCP\s+(?:server|client|tool)/i,
    ],
    filenamePatterns: [/^mcp\.json$/i, /^\.mcp\.json$/i, /mcp.*config.*\.json$/i],
  },
  {
    id: 'GUARDIAN-MCP-BRIDGE-001',
    capability: 'mcp',
    observation: 'MCP tool registration into an agent/tool action surface indicator detected',
    pathPatterns: [/(?:^|[\/._-])mcp(?:[\/._-]|$)/i],
    patterns: [
      /\bregister_to_tools\s*\(/i,
      /\bMCP\s+tools?\b.{0,100}\b(?:register(?:ed|ing)?|exposed|available)\b.{0,100}\b(?:agent|actions?|tools?)\b/i,
      /\b(?:register(?:ed|ing)?|exposed)\b.{0,100}\bMCP\s+tools?\b.{0,100}\b(?:agent|actions?|tools?)\b/i,
    ],
    agentRelevantHint: 'mcp_tool_bridge',
  },
  {
    id: 'GUARDIAN-APPROVAL-001',
    capability: 'approval_or_boundary_control',
    observation: 'Approval, allow/deny, sandbox, or bounded-target control indicator detected',
    patterns: [
      /\b(?:requireApproval|requiresApproval|approvalRequired|humanApproval|approvalGate)\b/i,
      /\b(?:require_confirmation|requires_confirmation|human_in_the_loop)\b/i,
      /\b(?:allowlist|allowList|denylist|denyList)\b/,
      /\b(?:sandbox|boundedTargets?|bounded_targets?)\b/i,
    ],
  },
]);

/**
 * Inspect a repository without executing target code.
 *
 * The function reads bounded text files, records static indicators, preserves
 * exact file/line evidence, and returns observations for later human review.
 */
export function inspectGuardianCapabilities(rootInput = '.', options = {}) {
  const root = resolveDirectory(rootInput);
  const limits = { ...DEFAULT_LIMITS, ...(options.limits || {}) };
  const inventory = discoverReadableFiles(root, limits);
  const observations = [];

  for (const file of inventory.files) {
    const absolutePath = path.join(root, file.relativePath);
    let text;
    try {
      text = fs.readFileSync(absolutePath, 'utf8');
    } catch {
      continue;
    }
    // A NUL byte is a strong signal that a file is binary rather than source text.
    if (text.includes('\u0000')) continue;

    const basename = path.basename(file.relativePath);
    for (const detector of DETECTORS) {
      if (!detectorAppliesToPath(detector, file.relativePath)) continue;
      if (detector.filenamePatterns?.some((pattern) => pattern.test(basename))) {
        observations.push(makeObservation(detector, file.relativePath, 1));
      }
    }

    const lines = text.split(/\r?\n/);
    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const lineNumber = index + 1;

      for (const detector of DETECTORS) {
        if (!detectorAppliesToPath(detector, file.relativePath)) continue;
        if (detector.patterns.some((pattern) => pattern.test(line))) {
          observations.push(makeObservation(detector, file.relativePath, lineNumber));
        }
      }

      // Store only the sensitive environment variable NAME. The secret value is
      // neither parsed nor returned, which keeps Guardian evidence non-secret.
      for (const envName of extractSensitiveEnvironmentReferences(line, basename)) {
        observations.push({
          detector_id: 'GUARDIAN-CRED-001',
          capability: 'credential_reference',
          observation: `Credential-like environment variable reference detected: ${envName}`,
          evidence: {
            path: file.relativePath,
            line_start: lineNumber,
            line_end: lineNumber,
          },
          review_required: true,
        });
      }
    }
  }

  // Stable ordering and deduplication make repeated scans reproducible and make
  // evidence suitable for exact retest comparison.
  const deduped = deduplicateObservations(observations)
    .sort(compareObservations)
    .slice(0, limits.maxObservations);

  return {
    schema: GUARDIAN_SCHEMA,
    guardian: {
      version: GUARDIAN_VERSION,
      authority: 'observational_only',
      determines_findings: false,
      determines_severity: false,
      determines_readiness: false,
    },
    target: {
      path: root,
      ...gitIdentity(root),
    },
    scope: {
      files_considered: inventory.files.length,
      files_skipped_too_large: inventory.filesSkippedTooLarge,
      files_skipped_limit: inventory.filesSkippedLimit,
      total_bytes_readable: inventory.totalBytes,
      truncated: inventory.truncated,
    },
    summary: summarise(deduped),
    observations: deduped,
    authority_notice: 'Guardian does not determine deployment readiness. Human ARL review is required.',
  };
}

function resolveDirectory(rootInput) {
  const resolved = path.resolve(rootInput);
  let stat;
  try {
    stat = fs.statSync(resolved);
  } catch {
    throw new Error(`Guardian target does not exist: ${resolved}`);
  }
  if (!stat.isDirectory()) throw new Error(`Guardian target is not a directory: ${resolved}`);
  return fs.realpathSync(resolved);
}

/**
 * Build a bounded, read-only text inventory.
 * Symlinks are deliberately ignored so a repository cannot make Guardian walk
 * outside the selected target tree.
 */
function discoverReadableFiles(root, limits) {
  const files = [];
  let totalBytes = 0;
  let filesSkippedTooLarge = 0;
  let filesSkippedLimit = 0;
  let truncated = false;
  const stack = [root];

  while (stack.length > 0) {
    const current = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }
    entries.sort((a, b) => a.name.localeCompare(b.name));

    for (const entry of entries) {
      if (entry.isSymbolicLink()) continue;
      const absolutePath = path.join(current, entry.name);
      const relativePath = normaliseRelative(path.relative(root, absolutePath));

      if (entry.isDirectory()) {
        if (!IGNORED_DIRS.has(entry.name)) stack.push(absolutePath);
        continue;
      }
      if (!entry.isFile() || !isReadableTextCandidate(entry.name)) continue;
      if (files.length >= limits.maxFiles) {
        filesSkippedLimit += 1;
        truncated = true;
        continue;
      }

      let stat;
      try {
        stat = fs.statSync(absolutePath);
      } catch {
        continue;
      }
      if (stat.size > limits.maxReadableFileBytes) {
        filesSkippedTooLarge += 1;
        truncated = true;
        continue;
      }
      if (totalBytes + stat.size > limits.maxTotalReadBytes) {
        filesSkippedLimit += 1;
        truncated = true;
        continue;
      }
      totalBytes += stat.size;
      files.push({ relativePath, size: stat.size });
    }
  }

  files.sort((a, b) => a.relativePath.localeCompare(b.relativePath));
  return { files, totalBytes, filesSkippedTooLarge, filesSkippedLimit, truncated };
}

function isReadableTextCandidate(name) {
  const lower = name.toLowerCase();
  if (TEXT_BASENAMES.has(lower)) return true;
  if (lower.startsWith('.env.')) return true;
  return TEXT_EXTENSIONS.has(path.extname(lower));
}

function detectorAppliesToPath(detector, relativePath) {
  return !detector.pathPatterns || detector.pathPatterns.some((pattern) => pattern.test(relativePath));
}

function makeObservation(detector, relativePath, lineNumber) {
  return {
    detector_id: detector.id,
    capability: detector.capability,
    observation: detector.observation,
    evidence: {
      path: relativePath,
      line_start: lineNumber,
      line_end: lineNumber,
    },
    ...(detector.agentRelevantHint ? { agent_relevant_hint: detector.agentRelevantHint } : {}),
    review_required: true,
  };
}

function extractSensitiveEnvironmentReferences(line, basename) {
  const names = new Set();
  const patterns = [
    /\bprocess\.env\.([A-Za-z_][A-Za-z0-9_]*)/g,
    /\bprocess\.env\[['"]([A-Za-z_][A-Za-z0-9_]*)['"]\]/g,
    /\bDeno\.env\.get\(\s*['"]([A-Za-z_][A-Za-z0-9_]*)['"]\s*\)/g,
    /\bos\.getenv\(\s*['"]([A-Za-z_][A-Za-z0-9_]*)['"]\s*\)/g,
    /\bos\.environ(?:\.get\(\s*['"]([A-Za-z_][A-Za-z0-9_]*)['"]|\[\s*['"]([A-Za-z_][A-Za-z0-9_]*)['"]\s*\])/g,
  ];
  for (const pattern of patterns) {
    for (const match of line.matchAll(pattern)) {
      const name = match[1] || match[2];
      if (name && SENSITIVE_ENV_NAME.test(name)) names.add(name);
    }
  }

  if (basename === '.env' || basename.startsWith('.env.')) {
    const match = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=/);
    if (match && SENSITIVE_ENV_NAME.test(match[1])) names.add(match[1]);
  }
  return [...names].sort();
}

function deduplicateObservations(observations) {
  const seen = new Set();
  const output = [];
  for (const observation of observations) {
    const key = [
      observation.detector_id,
      observation.capability,
      observation.observation,
      observation.evidence.path,
      observation.evidence.line_start,
      observation.evidence.line_end,
    ].join('\u0000');
    if (seen.has(key)) continue;
    seen.add(key);
    output.push(observation);
  }
  return output;
}

function compareObservations(left, right) {
  return left.detector_id.localeCompare(right.detector_id)
    || left.evidence.path.localeCompare(right.evidence.path)
    || left.evidence.line_start - right.evidence.line_start
    || left.observation.localeCompare(right.observation);
}

function summarise(observations) {
  const capabilityCounts = {};
  for (const observation of observations) {
    capabilityCounts[observation.capability] = (capabilityCounts[observation.capability] || 0) + 1;
  }
  return {
    observation_count: observations.length,
    capabilities: Object.fromEntries(Object.entries(capabilityCounts).sort(([a], [b]) => a.localeCompare(b))),
    review_required: observations.length > 0,
  };
}

// Git commands here inspect repository identity only. Guardian never executes
// target application code or target-defined scripts.
function gitIdentity(root) {
  try {
    const revision = execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 3_000,
    }).trim();
    const status = execFileSync('git', ['-C', root, 'status', '--porcelain=v1', '--untracked-files=normal'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 3_000,
    });
    return { git_revision: revision || null, git_dirty: Boolean(status.trim()) };
  } catch {
    return { git_revision: null, git_dirty: null };
  }
}

function normaliseRelative(relativePath) {
  return relativePath.split(path.sep).join('/');
}