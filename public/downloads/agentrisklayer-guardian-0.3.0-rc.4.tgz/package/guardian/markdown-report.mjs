/**
 * ARL Guardian — customer report and technical evidence formatting
 * Author / Founder: Guillaume Strohecker
 * Project: AgentRiskLayer (AGENTRISKLAYER LTD)
 *
 * Customer-facing output is intentionally concise and path-safe. Raw evidence
 * is kept in a separate assessor appendix so the commercial report remains
 * readable without weakening the underlying evidence trail.
 */

import path from 'node:path';
import { classifyEvidenceContext } from './capability-surface.mjs';

const CONTEXT_LABELS = Object.freeze({
  agent_runtime: 'Agent runtime',
  agent_configuration: 'Agent/configuration',
  integration_surface: 'Integration surface',
  application_backend: 'Application backend',
  dashboard_ui: 'Dashboard/UI',
  application_source: 'Application source',
  repository_configuration: 'Repository configuration',
  example_or_sample: 'Example/sample',
  test_or_fixture: 'Test/fixture',
  developer_tooling: 'Developer tooling',
  documentation: 'Documentation',
});

/** Format the concise report intended for customer review. */
export function formatGuardianMarkdown(result) {
  const lines = [
    '# ARL Guardian — Capability Discovery Report',
    '',
    '> Observational decision support only. Guardian does not determine findings, severity, control applicability, or deployment readiness. Human ARL review is required.',
    '',
    '## Target',
    '',
    `- **Repository:** \`${escapeInline(targetLabel(result))}\``,
    `- **Revision:** ${result.target.git_revision ? `\`${escapeInline(result.target.git_revision)}\`` : 'Not a Git repository'}`,
    `- **Working tree:** ${result.target.git_dirty === null ? 'Unknown' : result.target.git_dirty ? 'Dirty' : 'Clean'}`,
    `- **Files considered:** ${result.scope.files_considered}`,
    `- **Scan truncated:** ${result.scope.truncated ? 'Yes' : 'No'}`,
    '',
    '## Executive summary',
    '',
    `Guardian observed **${result.summary.capability_count} capability families** supported by **${result.summary.observation_count} raw evidence references**.`,
    '',
    'The capability surface separates likely agent-runtime/configuration evidence from integration surfaces, application backend, UI, examples/tests, tooling, and other repository evidence. Context labels are organisational heuristics only and do not prove runtime reachability or agent authority.',
    '',
    '## Capability surface',
    '',
    '| Capability | Evidence | Agent-linked evidence | Authority-chain evidence | Candidate ARL architecture facts | Review |',
    '| --- | ---: | ---: | ---: | --- | --- |',
  ];

  if (!result.capability_surface.length) {
    lines.push('| None observed | 0 | 0 | 0 | None | Human review still required for scan coverage |');
  } else {
    const handoffByCapability = new Map((result.review_handoff?.items || []).map((item) => [item.capability, item]));
    for (const surface of result.capability_surface) {
      const handoff = handoffByCapability.get(surface.capability);
      const facts = handoff?.candidate_architecture_facts?.map((entry) => `\`${escapeInline(entry.fact)}\``).join(', ') || 'None automatically prepared';
      lines.push(`| ${escapeTable(surface.display_name)} | ${formatEvidenceCount(surface.evidence_count, surface.file_count)} | ${handoff?.agent_relevant_evidence_count ?? 0} | ${handoff?.authority_evidence_count ?? 0} | ${facts} | Required |`);
    }
  }

  lines.push('', '## ARL review handoff', '');
  if (!result.review_handoff?.items?.length) {
    lines.push('No capability handoff items were generated.');
  } else {
    for (const item of result.review_handoff.items) {
      const facts = item.candidate_architecture_facts.map((entry) => `\`${escapeInline(entry.fact)}\``);
      lines.push(
        `### ${item.display_name}`,
        '',
        `- **Evidence references:** ${item.evidence_count}`,
        `- **Agent-linked evidence:** ${item.agent_relevant_evidence_count}`,
        `- **Authority-chain evidence:** ${item.authority_evidence_count ?? 0}`,
        `- **Candidate ARL architecture facts:** ${facts.length ? facts.join(', ') : 'None automatically prepared'}`,
        '- **Status:** Human confirmation required',
        '',
        '**Questions for assessment**',
        '',
        ...item.review_questions.map((question) => `- ${question}`),
        '',
        `**Next step:** ${item.next_step}`,
        '',
        `**Limitation:** ${item.limitations}`,
        '',
      );
    }
  }

  // Raw line-level evidence is deliberately not embedded in the customer report.
  lines.push(
    '## Technical evidence',
    '',
    `The ${result.summary.observation_count} raw evidence references are preserved in a separate technical evidence appendix for assessor review.`,
    '',
    '## Authority boundary',
    '',
    '- Guardian observations are not ARL findings.',
    '- Candidate architecture facts are not confirmed architecture facts.',
    '- Guardian does not assign severity.',
    '- Guardian does not determine control applicability.',
    '- Guardian does not determine deployment readiness.',
    '- Human ARL review is required before authoritative assessment decisions.',
    '',
  );

  return `${lines.join('\n')}\n`;
}

/** Format the full line-level evidence appendix for assessor use. */
export function formatGuardianEvidenceMarkdown(result) {
  const lines = [
    '# ARL Guardian — Technical Evidence Appendix',
    '',
    '> Raw observational evidence for assessor review. Entries are not findings and do not establish severity, applicability, or deployment readiness.',
    '',
    '## Target',
    '',
    `- **Repository:** \`${escapeInline(targetLabel(result))}\``,
    `- **Revision:** ${result.target.git_revision ? `\`${escapeInline(result.target.git_revision)}\`` : 'Not a Git repository'}`,
    `- **Files considered:** ${result.scope.files_considered}`,
    `- **Raw evidence references:** ${result.summary.observation_count}`,
    '',
    '## Evidence appendix',
    '',
    '| ID | Detector | Capability | Context | Evidence |',
    '| --- | --- | --- | --- | --- |',
  ];

  if (!result.observations.length) {
    lines.push('| — | — | — | — | No capability indicators detected in scanned text scope |');
  } else {
    result.observations.forEach((item, index) => {
      const context = classifyEvidenceContext(item.evidence.path);
      lines.push(`| G-${String(index + 1).padStart(3, '0')} | \`${escapeInline(item.detector_id)}\` | ${escapeTable(item.capability)} | ${escapeTable(CONTEXT_LABELS[context] || context)} | \`${escapeInline(item.evidence.path)}:${item.evidence.line_start}\` |`);
    });
  }

  lines.push(
    '',
    '## Authority boundary',
    '',
    '- Evidence references are observations, not ARL findings.',
    '- Context labels are heuristic organisational classifications.',
    '- Candidate architecture facts require human confirmation.',
    '- Guardian does not assign severity or determine control applicability.',
    '- Guardian does not determine deployment readiness.',
    '',
  );

  return `${lines.join('\n')}\n`;
}

// Strip the operator's local absolute path from shareable output.
function targetLabel(result) {
  const raw = String(result?.target?.path || 'repository').replaceAll('\\', '/').replace(/\/+$/, '');
  return path.posix.basename(raw) || 'repository';
}

function formatEvidenceCount(evidenceCount, fileCount) {
  const fileWord = fileCount === 1 ? 'file' : 'files';
  return `${evidenceCount} across ${fileCount} ${fileWord}`;
}

function escapeInline(value) {
  return String(value ?? '').replaceAll('`', '\\`');
}

function escapeTable(value) {
  return String(value ?? '').replaceAll('|', '\\|').replaceAll('\n', ' ');
}
