/**
 * ARL Guardian — capability surface and context classification
 * Author / Founder: Guillaume Strohecker
 * Project: AgentRiskLayer (AGENTRISKLAYER LTD)
 *
 * This module compresses raw static observations into capability families and
 * applies conservative path-based context labels. Context is organisational
 * evidence only; it never proves runtime reachability or agent authority.
 */

export const GUARDIAN_SURFACE_VERSION = '0.3.0';

const CAPABILITY_DISPLAY = Object.freeze({
  approval_or_boundary_control: 'Approval / boundary control',
  credential_reference: 'Credential reference',
  filesystem_write: 'Filesystem mutation',
  mcp: 'MCP integration',
  outbound_network: 'Outbound network',
  process_execution: 'Process execution',
});

const AGENT_RELEVANT_CONTEXTS = new Set(['agent_runtime', 'agent_configuration']);
const SEMANTIC_HINT_EXCLUDED_CONTEXTS = new Set([
  'example_or_sample',
  'test_or_fixture',
  'developer_tooling',
  'documentation',
]);

// Stable order keeps reports deterministic and easier to compare across retests.
const CONTEXT_ORDER = Object.freeze([
  'agent_runtime',
  'agent_configuration',
  'integration_surface',
  'application_backend',
  'dashboard_ui',
  'application_source',
  'repository_configuration',
  'example_or_sample',
  'test_or_fixture',
  'developer_tooling',
  'documentation',
]);

/** Add the grouped capability surface without changing raw observations. */
export function enrichGuardianResult(result) {
  const capabilitySurface = buildCapabilitySurface(result.observations || []);
  return {
    ...result,
    guardian: {
      ...result.guardian,
      version: GUARDIAN_SURFACE_VERSION,
      context_classification: 'path_plus_semantic_bridge',
    },
    summary: {
      ...result.summary,
      capability_count: capabilitySurface.length,
    },
    capability_surface: capabilitySurface,
  };
}

/**
 * Group evidence by capability while retaining counts, source files, detectors,
 * contexts, and primary components. No grouping step creates a security finding.
 */
export function buildCapabilitySurface(observations) {
  const groups = new Map();

  for (const observation of observations) {
    const context = classifyEvidenceContext(observation.evidence.path);
    const component = componentFromPath(observation.evidence.path, context);
    if (!groups.has(observation.capability)) {
      groups.set(observation.capability, {
        capability: observation.capability,
        display_name: CAPABILITY_DISPLAY[observation.capability] || observation.capability,
        observed: true,
        evidence_count: 0,
        agent_relevant_evidence_count: 0,
        authority_evidence_count: 0,
        files: new Set(),
        detectorIds: new Set(),
        contexts: new Map(),
        components: new Map(),
        review_required: true,
      });
    }

    const group = groups.get(observation.capability);
    group.evidence_count += 1;
    const semanticHintIsRelevant = Boolean(
      observation.agent_relevant_hint
      && !SEMANTIC_HINT_EXCLUDED_CONTEXTS.has(context)
    );
    if (AGENT_RELEVANT_CONTEXTS.has(context) || semanticHintIsRelevant) {
      group.agent_relevant_evidence_count += 1;
    }

    if (semanticHintIsRelevant) {
      group.authority_evidence_count += 1;
    }
    group.files.add(observation.evidence.path);
    group.detectorIds.add(observation.detector_id);
    increment(group.contexts, context);
    increment(group.components, component);
  }

  return [...groups.values()]
    .map((group) => ({
      capability: group.capability,
      display_name: group.display_name,
      observed: group.observed,
      evidence_count: group.evidence_count,
      agent_relevant_evidence_count: group.agent_relevant_evidence_count,
      authority_evidence_count: group.authority_evidence_count,
      file_count: group.files.size,
      detector_ids: [...group.detectorIds].sort(),
      contexts: sortContextCounts(group.contexts),
      primary_components: sortCountEntries(group.components)
        .slice(0, 6)
        .map(([component, count]) => ({ component, evidence_count: count })),
      review_required: group.review_required,
    }))
    .sort((left, right) => left.display_name.localeCompare(right.display_name));
}

/**
 * Classify evidence by path only.
 *
 * The ordering is deliberate: examples/tests/docs/tooling are classified before
 * generic "agent", "tool", or "mcp" path markers so non-production material
 * cannot accidentally become agent-relevant evidence.
 */
export function classifyEvidenceContext(relativePath) {
  const normalised = normaliseRelative(relativePath);
  const lower = normalised.toLowerCase();
  const basename = lower.split('/').at(-1) || lower;
  const segments = lower.split('/');

  if (
    segments.some((segment) => ['examples', 'example', 'samples', 'sample', 'demos', 'demo', 'tutorials', 'tutorial'].includes(segment))
  ) return 'example_or_sample';

  if (
    segments.some((segment) => ['tests', 'test', 'testing', 'fixtures', 'fixture', '__tests__', 'spec', 'specs'].includes(segment))
    || /^(?:test_.*|.*_test)\.(?:js|mjs|cjs|ts|tsx|jsx|py|rb|go|rs|java|kt|cs|php|swift|dart)$/.test(basename)
    || /\.test\.(?:js|mjs|cjs|ts|tsx|jsx)$/.test(basename)
  ) return 'test_or_fixture';

  if (segments.some((segment) => ['docs', 'doc', 'documentation'].includes(segment))) return 'documentation';

  if (
    segments.some((segment) => ['scripts', 'script', 'devtools', 'tooling'].includes(segment))
    || segments.includes('.github')
  ) return 'developer_tooling';

  if (
    /^(?:dashboard|web|frontend|ui)\/.*\/api\//.test(lower)
    || /^(?:dashboard|web|frontend|ui)\/(?:api|server|backend)\//.test(lower)
    || segments.some((segment) => ['server', 'backend'].includes(segment))
  ) return 'application_backend';

  if (
    /^(?:dashboard|web|frontend|ui)\//.test(lower)
    && (segments.includes('components') || segments.includes('pages') || segments.includes('app'))
  ) return 'dashboard_ui';

  if (
    segments.some((segment) => /^(?:agent|agents|agent_worker|agentworker|workers?|mcp_clients?|mcpmanagement|tool_mappers?|tools?|code_executors?)$/.test(segment))
    || /(?:^|\/)(?:agent|agents|agent_worker|agentworker|worker|workers|mcp_client|mcp_clients|mcpmanagement|tool_mapper|tool_mappers|code_executor|code_executors)\.(?:js|mjs|cjs|ts|tsx|jsx|py|rb|go|rs|java|kt|cs|php|swift|dart)$/.test(lower)
  ) return 'agent_runtime';

  if (
    segments.some((segment) => ['mcp', 'skills', 'plugins', 'connectors', 'extensions'].includes(segment))
    || ['tool.py', 'tools.py'].includes(basename)
  ) return 'integration_surface';

  if (
    segments.includes('config')
    || /(?:^|[._-])config(?:[._-]|$)/.test(basename)
    || ['package.json', 'pyproject.toml', 'requirements.txt', 'mcp.json', '.mcp.json', 'claude_desktop_config.json'].includes(basename)
  ) return 'agent_configuration';

  if (
    ['dockerfile', 'makefile', 'procfile'].includes(basename)
    || /\.(?:ya?ml|toml|ini|conf|cfg|properties|tf|hcl)$/.test(basename)
  ) return 'repository_configuration';

  return 'application_source';
}

/** Return a short component label for customer and assessor summaries. */
export function componentFromPath(relativePath, context = classifyEvidenceContext(relativePath)) {
  const parts = normaliseRelative(relativePath).split('/').filter(Boolean);
  if (parts.length <= 1) return 'repository_root';

  if (context === 'application_backend' && parts.length >= 3 && parts[1] === 'app' && parts[2] === 'api') {
    return parts.slice(0, 3).join('/');
  }

  if (context === 'dashboard_ui' && parts.length >= 2) return parts.slice(0, 2).join('/');

  return parts.slice(0, Math.min(2, parts.length)).join('/');
}

function increment(map, key) {
  map.set(key, (map.get(key) || 0) + 1);
}

function sortContextCounts(contextMap) {
  const result = {};
  for (const context of CONTEXT_ORDER) {
    const count = contextMap.get(context);
    if (count) result[context] = count;
  }
  for (const [context, count] of [...contextMap.entries()].sort(([a], [b]) => a.localeCompare(b))) {
    if (!Object.hasOwn(result, context)) result[context] = count;
  }
  return result;
}

function sortCountEntries(countMap) {
  return [...countMap.entries()].sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0]));
}

function normaliseRelative(relativePath) {
  return String(relativePath || '').replaceAll('\\', '/');
}